
i was travelling across america and i found this town that sells only small bottles of coke. Well ig that's mini-soda for you
Do you know why the British don't pronounce their t's all the time when they speak like when they say "Bri'ish"?   Because the America's dumped most of them.
Did you guys hear about the cops arresting a bottle of water because it was wanted in three different states: solid, liquid, and gas
my wife wont let me get a grizzly tatoo on each arm. she's interfereing with my right to bear arms
don’t mean to brag but cashiers keep checking me out
How much does a roof cost?    Nothing.... It's on the house.
A limbo champion walks into a bar... They're disqualified.
What kind of magic do cows believe in? MOODOO.
What do you call a boat full of buddies? A friendship
I ordered a chicken and an egg form amazong. I'll let you know
what do you get when you cross a cheep and a cow? a baaaaaaad mooooooood
What do you call a lying cereal? Cap n'crunch
Why are waterbeds so bouncy ? coz they are filled with spring water
What do you count a hen that counts her own eggs? A mathmachicken
Coffee has a tough time at my house, every morning it gets mugged.
Where did Captain Hook get his hook? From a second hand store.
What's the best thing about Switzerland?" "I don't know, but the flag is a big plus.
Have you heard about the chocolate record player? It sounds pretty sweet
My wife said I should do lunges to stay in shape. That would be a big step forward
my girlfriend broke up with me when she found out i only had 9 toes..... she was lack toes intolerant
How much does the rainbow weigh? Not much, its pretty light
Why'd billy get fired from the banana factory? Kept throwing away the bent ones
What would you do if you're addicted to sea weed? Sea kelp
I tried to come up with a carpentry pun.....that woodwork. I think I nailed it, but nobody saw it
What do lawyers wear to work? Law suits
Why did the crab cross the road? It didn’t it used the sidewalk
I went scuba diving once & knocked out a tooth ... but don't worry, it was in-sea-dental.
I like telling dad jokes. Sometimes he laughs
Mom asked me too go get 6 cans of sprite but when I got home I realized I picked 7up
I’ve got an interview tomorrow to become the boss at Old McDonald’s Farm. It’s for the position of CIEIO.
Saw a baguette at the zoo. It was bread in captivity.
What car does a Yedi drive? A toy-yoda
I lost my wife cuz of my gambling addiction but don’t worry, I know I’ll win her back
My wife traumaticly ripped the blanket off my last night. But dont worry, I will recover
Why did the pig get hired at the restaurant? Because he's really good at bacon.
A pun walks into the room and kills ten peeps. Pun in, ten dead
The doc said I was goin deaf. The news were hard for me to hear
You know, I was staring at the ceiling one day. I was confused why I was, it's not the best of ceilings, but it's up there.
What do you call a chubby psychic? A 4 chin teller
I am terrified of elevators. I’m going to start taking steps to avoid them.